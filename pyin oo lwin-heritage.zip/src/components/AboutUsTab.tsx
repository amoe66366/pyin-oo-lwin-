/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Globe, Users, ArrowUpRight, Download, Map as MapIcon } from 'lucide-react';

interface AboutUsTabProps {
  language?: 'en' | 'my';
}

export default function AboutUsTab({ language = 'en' }: AboutUsTabProps) {
  const isMyanmar = language === 'my';

  const handleDownloadMap = async (e: React.MouseEvent) => {
    e.preventDefault();
    // A clean high-resolution illustration / scenic plan representing Pyin Oo Lwin
    const imageUrl = "https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=1600&auto=format&fit=crop&q=100";
    const filename = "Pyin Oo Lwin National Botanical Gardens Map.jpg";

    try {
      const response = await fetch(imageUrl, { mode: 'cors' });
      if (!response.ok) throw new Error('Network response not ok');
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch (error) {
      console.warn("Direct blob download failed, opening image source URL directly for saving:", error);
      const link = document.createElement('a');
      link.href = imageUrl;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="flex flex-col gap-6 text-slate-800 pb-8 animate-fade-in">
      
      {/* SECTION 1: HERO HEADER */}
      <div className="relative rounded-3xl overflow-hidden h-44 shadow-md border border-white/40 bg-slate-100 flex items-end">
        <img 
          src="https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=800&auto=format&fit=crop&q=70" 
          alt="Pyin Oo Lwin Botanical Gardens"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover brightness-[0.7] transform scale-100 hover:scale-105 transition-transform duration-700"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/30 to-transparent"></div>
        <div className="relative z-10 p-5 text-white">
          <span className="text-[9px] uppercase tracking-widest font-extrabold text-emerald-300 font-mono">
            {isMyanmar ? 'ကျွန်ုပ်တို့၏ အမွေအနှစ် ရည်မှန်းချက်' : 'Our Heritage Mission'}
          </span>
          <h2 className="text-sm font-black tracking-tight leading-tight mt-0.5">
            {isMyanmar ? 'ပြင်ဦးလွင် ရှေးဟောင်းအမွေအနှစ် ထိန်းသိမ်းရေး' : 'Pyin Oo Lwin Heritage Protection'}
          </h2>
          <p className="text-[10px] text-slate-300 font-medium leading-relaxed mt-1">
            {isMyanmar 
              ? 'သမိုင်းဝင် အဆောက်အအုံများနှင့် သဘာဝအလှတရားများကို ခေတ်မီ ခြေရာခံစနစ်ဖြင့် ချိတ်ဆက်ပေးခြင်း။' 
              : 'Preserving highland history, legendary carriage culture, and botanical legacy.'}
          </p>
        </div>
      </div>

      {/* HISTORICAL MAP DOWNLOAD ARCHIVE */}
      <section className="bg-gradient-to-br from-emerald-500/10 to-teal-500/5 backdrop-blur-xl rounded-3xl p-5 border border-emerald-500/20 shadow-sm flex flex-col gap-3">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-emerald-500 text-white rounded-2xl shadow-md shrink-0">
            <MapIcon className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-wider block leading-tight font-sans">
              {isMyanmar ? 'ပြင်ဦးလွင် ရုက္ခဗေဒဥယျာဉ် လမ်းညွှန်မြေပုံ' : 'Pyin Oo Lwin Botanical Gardens Plan'}
            </h3>
            <span className="text-[9.5px] text-emerald-700 font-bold uppercase tracking-wider block mt-0.5 font-mono">
              {isMyanmar ? 'အရည်အသွေးမြင့် ပုံရိပ်ကို သိမ်းဆည်းရန်' : 'High-Resolution Botanical Map'}
            </span>
          </div>
        </div>
        
        <p className="text-[11px] text-slate-600 leading-relaxed font-semibold">
          {isMyanmar 
            ? 'ပြင်ဦးလွင်မြို့၏ အထင်ကရ အမျိုးသားကန်တော်ကြီး ရုက္ခဗေဒဥယျာဉ်၏ လှပသော လမ်းညွှန်မြေပုံပုံရိပ်ကို သင့်ဖုန်းထဲသို့ သိမ်းဆည်းကာ လေ့လာနိုင်ရန် ဖြစ်သည်။'
            : 'Download the high-resolution, beautiful garden layout and trail guide of the National Kandawgyi Botanical Gardens. Perfect for offline exploration and historical orientation.'}
        </p>

        <button
          id="download-pyin-oo-lwin-map-btn"
          onClick={handleDownloadMap}
          className="w-full mt-1.5 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] transition-all text-white rounded-2xl flex items-center justify-center gap-2.5 shadow-lg shadow-emerald-200/30 text-xs font-black cursor-pointer select-none"
        >
          <Download className="w-4 h-4 text-white" />
          <span>{isMyanmar ? 'လမ်းညွှန်မြေပုံ ဒေါင်းလုဒ်ဆွဲပါ' : 'Download Garden Map'}</span>
        </button>
      </section>

      {/* SECTION 2: INTRODUCTION / MISSION STATEMENT */}
      <section className="bg-white/80 backdrop-blur-xl rounded-3xl p-5 border border-white/80 shadow-sm flex flex-col gap-2.5">
        <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-1.5 border-b border-slate-100 pb-1.5">
          <Globe className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{isMyanmar ? 'စီမံကိန်းအကြောင်း' : 'About Pyin Oo Lwin (Maymyo)'}</span>
        </h3>
        <p className="text-[11px] text-slate-600 leading-relaxed font-semibold">
          {isMyanmar 
            ? 'ပင်လယ်ရေမျက်နှာပြင်အထက် ပေ ၃၅၀၀ ကျော်တွင် တည်ရှိသော ပြင်ဦးလွင်မြို့ (ယခင် မေမြို့) သည် ရှေးဟောင်းကိုလိုနီခေတ် အုတ်နီရောင်အိမ်ကြီးများ၊ ကော်ဖီစိုက်ခင်းများ၊ လှပသောရေတံခွန်များနှင့် ရိုးရာမြင်းလှည်းလေးများကြောင့် နာမည်ကျော်ကြားလှသော တောင်ပေါ်အပန်းဖြေမြို့လေး ဖြစ်သည်။'
            : 'Perched over 3,500 feet above sea level in the Shan Hills, Pyin Oo Lwin (formerly Maymyo) is Myanmar\'s premier scenic retreat. Known for its cool mountain air, horse-drawn carriages, pine forests, and stunning Tudor-style colonial mansions, it represents a unique cultural and environmental sanctuary.'}
        </p>
        <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
          {isMyanmar 
            ? 'ဤအပြန်အလှန်အကျိုးပြုမြေပုံသည် ခရီးသွားများနှင့် ထိန်းသိမ်းသူများအား သမိုင်းဝင်ပုရှဲလ်နာရီစင်၊ သီရိမြိုင်အိမ်တော် (ကန္ဒာခရိတ်) နှင့် သဘာဝရေတံခွန်ဂူများကို လွယ်ကူစွာ ရှာဖွေနိုင်ရန် GPS နှင့် မြေပုံစနစ်များ ပေါင်းစပ်လမ်းညွှန်ပေးမည် ဖြစ်သည်။'
            : 'This interactive explorer tracks coordinates, local histories, and conservation statuses of both architectural and natural heritage landmarks, ensuring Maymyo\'s legacy is celebrated and preserved for future generations.'}
        </p>
      </section>

      {/* SECTION 3: THE TEAM / DIRECTORY */}
      <section className="bg-white/80 backdrop-blur-xl rounded-3xl p-5 border border-white/80 shadow-sm flex flex-col gap-3">
        <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-1.5 border-b border-slate-100 pb-1.5 font-sans">
          <Users className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{isMyanmar ? 'ထိန်းသိမ်းသူများနှင့် ဖန်တီးသူများ' : 'Curators & Developers'}</span>
        </h3>
        
        <div className="grid grid-cols-1 gap-3.5 mt-1">
          {/* TEAM MEMBER 1 */}
          <div className="flex items-center gap-3 bg-white/50 p-2.5 rounded-2xl border border-slate-100/50">
            <div className="w-10 h-10 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 font-black flex items-center justify-center text-sm shadow-inner shrink-0">
              MA
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-[11px] font-extrabold text-slate-800 leading-none">Mikel Ainsworth</h4>
              <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block mt-1 font-mono">
                {isMyanmar ? 'ဦးဆောင် ထိန်းသိမ်းသူ / ဒီဇိုင်နာ' : 'Lead Curator / Designer'}
              </span>
            </div>
          </div>

          {/* TEAM MEMBER 2 */}
          <div className="flex items-center gap-3 bg-white/50 p-2.5 rounded-2xl border border-slate-100/50">
            <div className="w-10 h-10 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-600 font-black flex items-center justify-center text-sm shadow-inner shrink-0">
              TC
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-[11px] font-extrabold text-slate-800 leading-none">Thura Chit</h4>
              <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block mt-1 font-mono">
                {isMyanmar ? 'တောင်ပေါ်သမိုင်းနှင့် မော်ကွန်းပညာရှင်' : 'Highland Archival Specialist'}
              </span>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
