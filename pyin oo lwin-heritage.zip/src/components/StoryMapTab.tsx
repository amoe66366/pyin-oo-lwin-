/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, ChevronLeft, MapPin, Sparkles, RefreshCw, Compass, Globe, Info } from 'lucide-react';

interface StorySlide {
  title: string;
  titleMy: string;
  description: string;
  descriptionMy: string;
  imageUrl: string;
  latitude: number;
  longitude: number;
  locationName: string;
  locationNameMy: string;
  era: string;
}

const STORY_SLIDES: StorySlide[] = [
  {
    title: "Highland Retreat & Botanical Splendor",
    titleMy: "တောင်ပေါ်မြို့လေးနှင့် ရုက္ခဗေဒအလှအပ",
    description: "Welcome to Pyin Oo Lwin, nestled at 3,510 feet in the scenic Shan Hills. Renowned for its cool mountain air, vibrant flower crops, and pine-clad roads, it stands as Myanmar's premier historic hill retreat, established over a century ago.",
    descriptionMy: "ရှမ်းကုန်းပြင်မြင့် ပေပေါင်း ၃၅၀၀ ကျော်တွင် တည်ရှိပြီး သဘာဝပန်းမန်မျိုးစုံ၊ ထင်းရှူးတောများနှင့် ကိုလိုနီခေတ်အဆောက်အအုံများ စုစည်းရာဖြစ်ပြီး လွန်ခဲ့သော ရာစုနှစ်တစ်ခုကျော်ကတည်းက တောင်ပေါ်အပန်းဖြေမြို့အဖြစ် ထင်ရှားခဲ့သည်။",
    imageUrl: "https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=1000&auto=format&fit=crop&q=80",
    latitude: 21.9961,
    longitude: 96.4716,
    locationName: "National Kandawgyi Gardens",
    locationNameMy: "အမျိုးသားကန်တော်ကြီး ရုက္ခဗေဒဥယျာဉ်",
    era: "Est. 1915"
  },
  {
    title: "Vibrant Horse-Drawn Carriages",
    titleMy: "ရိုးရာမြင်းလှည်းလေးများ၏ မြို့တော်",
    description: "Pyin Oo Lwin is the only town in Myanmar where colourful 19th-century horse-drawn carriages, known as 'Myin Hlay', continue to serve as active street transport, maintaining a living, rhythmic pulse of history along the pine avenues.",
    descriptionMy: "မြန်မာနိုင်ငံတွင် ကိုလိုနီခေတ် မြင်းလှည်းလေးများကို ယနေ့တိုင် အငှားယာဉ်အဖြစ် တက်ကြွစွာ တွေ့မြင်စီးနင်းနိုင်ဆဲ တစ်ခုတည်းသော သမိုင်းဝင်မြို့လေး ဖြစ်သည်။",
    imageUrl: "https://images.unsplash.com/photo-1545569341-9eb8b30979d9?w=1000&auto=format&fit=crop&q=80",
    latitude: 22.0294,
    longitude: 96.4674,
    locationName: "Purcell Clock Tower Precinct",
    locationNameMy: "ပုရှဲလ်နာရီစင် အနီးတစ်ဝိုက်",
    era: "Living Legacy"
  },
  {
    title: "Classical Tudor Masonry: Candacraig",
    titleMy: "ဗိသုကာလက်ရာမြောက် သီရိမြိုင်အိမ်တော်",
    description: "Built in 1904 as a guest house for Bombay Burmah Trading Corporation, this stunning Tudor-style red brick mansion showcases quintessential classical craftsmanship, high ceilings, and pine fireplaces.",
    descriptionMy: "၁၉၀၄ ခုနှစ်တွင် Bombay Burmah ကုမ္ပဏီ၏ ဧည့်ဂေဟာအဖြစ် တည်ဆောက်ခဲ့ပြီး ထင်းရှူးပင်များ ဝန်းရံထားသော ခမ်းနားလှပသည့် သီရိမြိုင်ကိုလိုနီအိမ်တော်ကြီး ဖြစ်သည်။",
    imageUrl: "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=1000&auto=format&fit=crop&q=80",
    latitude: 22.0183,
    longitude: 96.4801,
    locationName: "Candacraig Mansion (Thiri Myaing)",
    locationNameMy: "သီရိမြိုင်အိမ်တော် (ကန္ဒာခရိတ်)",
    era: "Built 1904"
  },
  {
    title: "The Heartbeat of Travel & Railways",
    titleMy: "သမိုင်းဝင် ပြင်ဦးလွင်ဘူတာရုံကြီး",
    description: "Constructed during the late Victorian railway expansion, this brick terminal is a vital station along the scenic railway route passing over the legendary Gokteik Viaduct, bridging Mandalay and Shan State.",
    descriptionMy: "၁၉ ရာစုနှောင်းပိုင်းတွင် တည်ဆောက်ခဲ့သော ကိုလိုနီခေတ်လက်ရာ ဘူတာရုံကြီးဖြစ်ပြီး၊ နာမည်ကျော် ဂုတ်ထိပ်တံတားကြီးဆီသို့ ဖြတ်သန်းမည့် ရထားခရီးစဉ်များ စတင်ရာ နေရာဖြစ်သည်။",
    imageUrl: "https://images.unsplash.com/photo-1513694203232-719a280e022f?w=1000&auto=format&fit=crop&q=80",
    latitude: 22.0272,
    longitude: 96.4626,
    locationName: "Pyin Oo Lwin Railway Station",
    locationNameMy: "ပြင်ဦးလွင် ဘူတာရုံ",
    era: "Est. 1890s"
  },
  {
    title: "Waterfalls & Natural Caves",
    titleMy: "ပိတ်ချင်းမြောင်လိုဏ်ဂူနှင့် ရေတံခွန်များ",
    description: "Pyin Oo Lwin's perimeter is blessed with limestone cascades and wet caves like Peik Chin Myaung, housing thousands of serene Buddhist shrines nestled amidst underground natural springs.",
    descriptionMy: "ပြင်ဦးလွင်မြို့ပတ်ပတ်လည်တွင် ပွဲကောက်ရေတံခွန်ကဲ့သို့ လှပသောရေတံခွန်များနှင့် ဗုဒ္ဓရုပ်ပွားတော်များ ပူဇော်ရာ ပိတ်ချင်းမြောင် သဘာဝလိုဏ်ဂူကြီး တည်ရှိသည်။",
    imageUrl: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1000&auto=format&fit=crop&q=80",
    latitude: 22.1001,
    longitude: 96.6167,
    locationName: "Peik Chin Myaung Cave Sanctuary",
    locationNameMy: "ပိတ်ချင်းမြောင် သဘာဝလိုဏ်ဂူ",
    era: "Ancient Geology"
  }
];

interface StoryMapTabProps {
  language?: 'en' | 'my';
}

export default function StoryMapTab({ language = 'en' }: StoryMapTabProps) {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [direction, setDirection] = useState(0); // -1 for left, 1 for right
  const isMyanmar = language === 'my';

  const slide = STORY_SLIDES[currentSlideIndex];

  const handleNext = () => {
    setDirection(1);
    setCurrentSlideIndex((prev) => (prev + 1) % STORY_SLIDES.length);
  };

  const handlePrev = () => {
    setDirection(-1);
    setCurrentSlideIndex((prev) => (prev - 1 + STORY_SLIDES.length) % STORY_SLIDES.length);
  };

  const handleRestart = () => {
    setDirection(-1);
    setCurrentSlideIndex(0);
  };

  // Custom slide animations
  const slideVariants = {
    enter: (dir: number) => ({
      x: dir > 0 ? 150 : -150,
      opacity: 0
    }),
    center: {
      x: 0,
      opacity: 1
    },
    exit: (dir: number) => ({
      x: dir < 0 ? 150 : -150,
      opacity: 0
    })
  };

  return (
    <div className="flex flex-col bg-white/50 backdrop-blur-xl text-slate-800 rounded-3xl overflow-hidden shadow-xl border border-white/60 min-h-[500px]">
      
      {/* Tab Header Banner */}
      <div className="px-5 py-4 bg-white/40 backdrop-blur-md border-b border-white/50 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-emerald-500/10 text-emerald-600 rounded-xl">
            <Compass className="w-5 h-5 animate-pulse" />
          </div>
          <div className="flex flex-col">
            <span className="font-bold text-sm tracking-tight text-slate-800 leading-tight">
              {isMyanmar ? 'အပြန်အလှန်အကျိုးပြု ခရီးသွားပုံပြင်များ' : 'Interactive StoryMap'}
            </span>
            <span className="text-[10px] text-slate-500 mt-0.5 uppercase tracking-wider font-mono font-semibold">
              {isMyanmar ? 'ပြင်ဦးလွင် ရှေးဟောင်းပုံပြင်များ' : 'Maymyo Narrative Tour'}
            </span>
          </div>
        </div>

        {/* Slide Counter / Reset Button */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-bold font-mono bg-emerald-50 text-emerald-800 px-2.5 py-1 rounded-lg border border-emerald-150">
            {currentSlideIndex + 1} / {STORY_SLIDES.length}
          </span>
          <button
            id="reset-story-tour-btn"
            onClick={handleRestart}
            className="p-1.5 bg-white/60 hover:bg-white/80 active:scale-95 rounded-xl border border-white/80 transition cursor-pointer text-slate-600"
            title={isMyanmar ? 'အစမှ ပြန်စရန်' : 'Restart Tour'}
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Narrative Area */}
      <div className="flex-1 p-5 sm:p-6 flex flex-col md:flex-row gap-6 items-stretch min-h-[380px]">
        
        {/* Left Side: Descriptive Text with Animated Transitions */}
        <div className="flex-1 flex flex-col justify-between gap-4 min-h-[220px]">
          <AnimatePresence mode="wait" custom={direction}>
            <motion.div
              key={currentSlideIndex}
              custom={direction}
              variants={slideVariants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{ duration: 0.3, ease: 'easeInOut' }}
              className="flex-1 flex flex-col gap-3"
            >
              {/* Era Badge */}
              <div>
                <span className="text-[9px] uppercase tracking-widest font-extrabold px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full font-mono border border-emerald-200/50">
                  {slide.era}
                </span>
              </div>

              {/* Title */}
              <h3 className="text-base font-black tracking-tight text-slate-800 leading-tight">
                {isMyanmar ? slide.titleMy : slide.title}
              </h3>

              {/* Description */}
              <p className="text-[12px] text-slate-600 leading-relaxed font-semibold">
                {isMyanmar ? slide.descriptionMy : slide.description}
              </p>

              {/* Map Coordinates detail */}
              <div className="mt-2 bg-slate-50/80 p-2.5 rounded-2xl border border-slate-100/50 flex items-center gap-2 text-[10px] text-slate-500 font-mono font-medium">
                <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span className="font-bold text-slate-700 truncate">
                  {isMyanmar ? slide.locationNameMy : slide.locationName}
                </span>
                <span className="text-slate-350 shrink-0">|</span>
                <span className="shrink-0">
                  {slide.latitude.toFixed(4)}°N, {slide.longitude.toFixed(4)}°E
                </span>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation Controllers */}
          <div className="flex items-center gap-3 border-t border-slate-100 pt-4 shrink-0 mt-auto">
            <button
              id="prev-slide-btn"
              onClick={handlePrev}
              className="p-3 bg-white hover:bg-slate-50 border border-slate-200/60 rounded-2xl transition cursor-pointer active:scale-95 flex items-center justify-center text-slate-600"
              title="Previous Slide"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            
            <button
              id="next-slide-btn"
              onClick={handleNext}
              className="flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] transition-all text-white rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-200/30 text-xs font-black cursor-pointer select-none"
            >
              <span>{isMyanmar ? 'შემდეგი' : 'Next Story'}</span>
              <ChevronRight className="w-4 h-4 text-white" />
            </button>
          </div>
        </div>

        {/* Right Side: Visual Image Frame */}
        <div className="w-full md:w-[280px] lg:w-[320px] rounded-2xl overflow-hidden shadow-md border border-white/50 relative bg-slate-100 shrink-0 min-h-[220px]">
          <AnimatePresence mode="wait" custom={direction}>
            <motion.img
              key={currentSlideIndex}
              src={slide.imageUrl}
              alt={slide.title}
              referrerPolicy="no-referrer"
              initial={{ opacity: 0, scale: 1.05 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.35 }}
              className="absolute inset-0 w-full h-full object-cover brightness-[0.88]"
            />
          </AnimatePresence>
          
          <div className="absolute top-3 left-3 z-10">
            <span className="flex items-center gap-1 bg-slate-950/70 backdrop-blur-md px-2 py-1 rounded-lg border border-slate-800 text-[8.5px] font-extrabold text-emerald-400 font-mono tracking-wider uppercase shadow">
              <Sparkles className="w-2.5 h-2.5 text-emerald-400 animate-pulse" />
              <span>{isMyanmar ? 'တိုက်ရိုက်ဓာတ်ပုံ' : 'Interactive Card'}</span>
            </span>
          </div>
        </div>

      </div>

      {/* Footer Instructions */}
      <div className="px-5 py-3.5 bg-white/40 border-t border-white/50 text-[10px] text-slate-500 flex items-center justify-center gap-1.5 shrink-0 select-none">
        <Info className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
        <span className="font-semibold">
          {isMyanmar 
            ? 'အပေါ်ရှိ ခလုတ်များကိုနှိပ်၍ ပြင်ဦးလွင်မြို့၏ အမွေအနှစ်ပုံရိပ်များကို အဆင့်ဆင့်လေ့လာကြည့်ရှုပါ။' 
            : 'Explore Pyin Oo Lwin\'s botanical wonders, colonial architecture, and carriage culture.'}
        </span>
      </div>
    </div>
  );
}
