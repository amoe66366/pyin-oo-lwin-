/**
 * Statcounter Analytics Integration
 * High-compatibility implementation designed for Single Page Applications (SPA)
 * and packaged Capacitor hybrid container environments (Android APK).
 */

// Fetches credentials statically compiled via .env environment variables
export function getStatcounterConfig() {
  const envProject = (import.meta as any).env?.VITE_STATCOUNTER_PROJECT || '';
  const envSecurity = (import.meta as any).env?.VITE_STATCOUNTER_SECURITY || '';
  
  return {
    project: envProject.trim(),
    security: envSecurity.trim(),
    isActive: !!(envProject.trim() && envSecurity.trim())
  };
}

let scriptInjected = false;

/**
 * Tracks a route/view change or dynamic item activation.
 * Sends a standard background script query and handles the image fallback hit 
 * to guarantee compatibility if protocols like `capacitor://` or `file://` block scripts.
 */
export function trackPageView(pageTitle: string) {
  const { project, security, isActive } = getStatcounterConfig();
  if (!isActive) return;

  try {
    // 1. Prepare global settings readable by counter.js
    (window as any).sc_project = parseInt(project, 10);
    (window as any).sc_security = security;
    (window as any).sc_invisible = 1;

    console.log(`[Statcounter Log] Tracking View event: "${pageTitle}"`);

    // 2. Inject counter.js dynamically if not already added to the document
    if (!scriptInjected) {
      const existingScript = document.getElementById('sc-tracker-script');
      if (!existingScript) {
        const script = document.createElement('script');
        script.id = 'sc-tracker-script';
        script.type = 'text/javascript';
        script.async = true;
        script.src = 'https://www.statcounter.com/counter/counter.js';
        script.onload = () => {
          scriptInjected = true;
        };
        document.head.appendChild(script);
      } else {
        scriptInjected = true;
      }
    }

    // 3. Dispatch an Image-Pixel query (highly robust fallback)
    // This is vital for Capacitor because WebViews with file://, localhost, or capacitor:// schemas
    // can sometimes block the external counter.js from mapping variables correctly,
    // but image element hits are consistently allowed through by Android System WebView.
    const rand = Math.floor(Math.random() * 10000000);
    const pixelUrl = `https://c.statcounter.com/${project}/0/${security}/1/?invisible=1&rand=${rand}&title=${encodeURIComponent(pageTitle)}&referrer=${encodeURIComponent(window.location.href)}`;
    
    const img = new Image();
    img.referrerPolicy = 'no-referrer-when-downgrade';
    img.src = pixelUrl;

  } catch (err) {
    console.warn('[Statcounter] Background tracking error:', err);
  }
}
